//= require easygrid.jqgrid
//= require selection/selectionWidget.js