//= require jquery
//= require ../jquery-ui-1.11.0/jquery-ui.js
//= require ../DataTables-1.10.0/media/js/jquery.dataTables.js
//= require ../DataTables-1.10.0/extensions/FixedColumns/js/dataTables.fixedColumns.js
//= require datatables/utils.js