println '''
 ******************************************************
* You've installed the Easygrid plugin.                *
*                                                      *
* Next run the "easygrid-setup" script to initialize   *
* EasygridConfig.groovy in grails-app/config           *
* and copy Easygrid templates to                       *
* grails-app/views/templates/easygrid                  *
*                                                      *
 ******************************************************
'''


